from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    full_name = forms.CharField(required=True)

    class Meta:
        model = User
        fields = ("username", "email", "full_name", "password1", "password2")

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("This email address is already in use.")
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        # Split full name into first_name and last_name
        full_name = self.cleaned_data["full_name"].split()
        if len(full_name) > 0:
            user.first_name = full_name[0]
            if len(full_name) > 1:
                user.last_name = " ".join(full_name[1:])
        
        if commit:
            user.save()
        return user 