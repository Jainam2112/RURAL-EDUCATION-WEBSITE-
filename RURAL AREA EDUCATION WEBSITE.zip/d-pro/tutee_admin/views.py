from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import CustomUserCreationForm
from main.models import Course, Contact, UserCourse, UserActivity

def home(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def services(request):
    return render(request, 'services.html')

def courses(request):
    courses = Course.objects.all()
    
    # Get list of courses that the user is subscribed to
    user_subscribed_courses = []
    if request.user.is_authenticated:
        user_courses = UserCourse.objects.filter(user=request.user).select_related('course')
        user_subscribed_courses = [user_course.course for user_course in user_courses]
    
    # Categorize courses by level
    beginner_courses = [course for course in courses if 'beginner' in course.level.lower()]
    intermediate_courses = [course for course in courses if 'intermediate' in course.level.lower()]
    advanced_courses = [course for course in courses if 'advanced' in course.level.lower()]
    
    return render(request, 'courses.html', {
        'courses': courses,
        'beginner_courses': beginner_courses,
        'intermediate_courses': intermediate_courses,
        'advanced_courses': advanced_courses,
        'user_subscribed_courses': user_subscribed_courses
    })

@login_required(login_url='/login/')
def dashboard(request):
    # Get the courses the user has subscribed to
    user_courses = UserCourse.objects.filter(user=request.user).select_related('course')
    
    # Get the user's recent activities
    user_activities = UserActivity.objects.filter(user=request.user).select_related('course')[:5]
    
    return render(request, 'dashboard.html', {
        'user': request.user,
        'user_courses': user_courses,
        'user_activities': user_activities
    })

def login_register(request):
    if request.user.is_authenticated:
        return redirect('home')
    return render(request, 'login.html')

def user_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        if not email or not password:
            messages.error(request, 'Please provide both email and password.')
            return redirect('login_register')

        try:
            user = User.objects.get(email=email)
            # Try authenticating with username
            auth_user = authenticate(request, username=user.username, password=password)
            
            if auth_user is not None:
                login(request, auth_user)
                messages.success(request, 'Successfully logged in!')
                return redirect('home')
            else:
                messages.error(request, 'Incorrect password.')
        except User.DoesNotExist:
            messages.error(request, f'No account found with email: {email}')
        return redirect('login_register')
    return redirect('login_register')

def user_register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Log the user in after registration
            login(request, user)
            messages.success(request, f'Registration successful! Welcome {user.first_name}!')
            return redirect('home')
        else:
            # If form is not valid, add form errors to messages
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{error}')
            return redirect('login_register')
    return redirect('login_register')

def contact(request):
    email = request.GET.get('email', '')
    
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        
        Contact.objects.create(
            name=name,
            email=email,
            subject=subject,
            message=message
        )
        return render(request, 'contact.html', {'message': 'Thank you for your message!'})
    
    return render(request, 'contact.html', {'email': email})

@login_required(login_url='/login/')
def subscribe_course(request, course_id):
    course = Course.objects.get(id=course_id)
    
    # Check if user is already subscribed to this course
    if not UserCourse.objects.filter(user=request.user, course=course).exists():
        # Create a new user course subscription
        UserCourse.objects.create(
            user=request.user,
            course=course,
            progress=0
        )
        
        # Create an activity for subscribing to the course
        UserActivity.objects.create(
            user=request.user,
            course=course,
            activity_type='subscribe',
            description=f'Subscribed to {course.title}'
        )
        
        messages.success(request, f'You have successfully subscribed to {course.title}!')
    else:
        messages.info(request, f'You are already subscribed to {course.title}.')
    
    return redirect('courses')

@login_required(login_url='/login/')
def update_progress(request, course_id):
    # This is a demo function to simulate progress updates
    user_course = UserCourse.objects.get(user=request.user, course_id=course_id)
    
    # Increase progress by 10% (simulating course advancement)
    new_progress = min(user_course.progress + 10, 100)
    user_course.progress = new_progress
    user_course.save()
    
    course = Course.objects.get(id=course_id)
    
    # Create an activity record
    if new_progress == 100:
        # If course is completed
        UserActivity.objects.create(
            user=request.user,
            course=course,
            activity_type='complete',
            description=f'Completed the {course.title} course'
        )
        messages.success(request, f'Congratulations! You have completed the {course.title} course.')
    elif new_progress % 25 == 0:
        # Every 25% milestone, create a certificate activity
        UserActivity.objects.create(
            user=request.user,
            course=course,
            activity_type='certificate',
            description=f'Earned {new_progress}% completion certificate in {course.title}'
        )
        messages.success(request, f'You earned a {new_progress}% completion certificate!')
    else:
        # Regular progress update
        UserActivity.objects.create(
            user=request.user,
            course=course,
            activity_type='progress',
            description=f'Made progress ({new_progress}%) in {course.title}'
        )
        messages.success(request, f'Your progress has been updated to {new_progress}%')
        
    return redirect('dashboard')

@login_required(login_url='/login/')
def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    # Get the user's course subscription
    user_course = None
    try:
        user_course = UserCourse.objects.get(user=request.user, course=course)
    except UserCourse.DoesNotExist:
        # If user hasn't subscribed but somehow got here, redirect to courses
        return redirect('courses')
    
    # Count enrolled students
    enrolled_students = UserCourse.objects.filter(course=course).count()
    
    return render(request, 'course_detail.html', {
        'course': course,
        'user_course': user_course,
        'enrolled_students': enrolled_students
    }) 