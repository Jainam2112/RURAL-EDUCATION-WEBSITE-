from django.contrib import admin
from .models import Service, Contact, About, HomeContent, Course, UserCourse, UserActivity

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at', 'updated_at')
    search_fields = ('title', 'description')
    list_filter = ('created_at', 'updated_at')

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'subject', 'created_at')
    search_fields = ('name', 'email', 'subject', 'message')
    list_filter = ('created_at',)
    readonly_fields = ('created_at',)

@admin.register(About)
class AboutAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at', 'updated_at')
    search_fields = ('title', 'content')
    list_filter = ('created_at', 'updated_at')

@admin.register(HomeContent)
class HomeContentAdmin(admin.ModelAdmin):
    list_display = ('hero_title', 'created_at', 'updated_at')
    search_fields = ('hero_title', 'hero_subtitle')
    list_filter = ('created_at', 'updated_at')

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'duration', 'level', 'price', 'created_at')
    search_fields = ('title', 'description')
    list_filter = ('level', 'created_at')
    readonly_fields = ('created_at', 'updated_at')
    fieldsets = (
        ('Basic Information', {
            'fields': ('title', 'description', 'image')
        }),
        ('Course Details', {
            'fields': ('duration', 'level', 'price')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(UserCourse)
class UserCourseAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'progress', 'subscribed_date', 'last_accessed')
    list_filter = ('course', 'subscribed_date')
    search_fields = ('user__username', 'user__email', 'course__title')
    raw_id_fields = ('user', 'course')
    readonly_fields = ('subscribed_date', 'last_accessed')

@admin.register(UserActivity)
class UserActivityAdmin(admin.ModelAdmin):
    list_display = ('user', 'activity_type', 'course', 'description', 'created_at')
    list_filter = ('activity_type', 'created_at')
    search_fields = ('user__username', 'user__email', 'course__title', 'description')
    raw_id_fields = ('user', 'course')
