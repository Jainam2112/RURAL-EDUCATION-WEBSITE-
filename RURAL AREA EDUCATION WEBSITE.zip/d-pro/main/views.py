from django.shortcuts import render, get_object_or_404, redirect
from .models import Service, About, HomeContent, Contact, Course, UserCourse, UserActivity
from django.contrib.auth.decorators import login_required

def home(request):
    home_content = HomeContent.objects.first()
    services = Service.objects.all()
    return render(request, 'index.html', {
        'home_content': home_content,
        'services': services
    })

def about(request):
    about_content = About.objects.first()
    return render(request, 'about.html', {
        'about_content': about_content
    })

def services(request):
    services = Service.objects.all()
    return render(request, 'services.html', {
        'services': services
    })

def contact(request):
    email = request.GET.get('email', '')
    
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        
        Contact.objects.create(
            name=name,
            email=email,
            subject=subject,
            message=message
        )
        return render(request, 'contact.html', {'message': 'Thank you for your message!'})
    
    return render(request, 'contact.html', {'email': email})

@login_required
def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    # Get the user's course subscription
    user_course = None
    try:
        user_course = UserCourse.objects.get(user=request.user, course=course)
    except UserCourse.DoesNotExist:
        # If user hasn't subscribed but somehow got here, redirect to courses
        return redirect('courses')
    
    # Count enrolled students
    enrolled_students = UserCourse.objects.filter(course=course).count()
    
    return render(request, 'course_detail.html', {
        'course': course,
        'user_course': user_course,
        'enrolled_students': enrolled_students
    })
