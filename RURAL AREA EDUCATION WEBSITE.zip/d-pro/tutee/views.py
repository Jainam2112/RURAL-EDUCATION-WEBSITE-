from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from main.models import Course, UserCourse, UserActivity

def home(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def services(request):
    return render(request, 'services.html')

def courses(request):
    courses = Course.objects.all()
    
    # Get list of courses that the user is subscribed to
    user_subscribed_courses = []
    if request.user.is_authenticated:
        user_courses = UserCourse.objects.filter(user=request.user).select_related('course')
        user_subscribed_courses = [user_course.course for user_course in user_courses]
    
    return render(request, 'courses.html', {
        'courses': courses,
        'user_subscribed_courses': user_subscribed_courses
    })

@login_required(login_url='/accounts/login/')
def dashboard(request):
    # Get the courses the user has subscribed to
    user_courses = UserCourse.objects.filter(user=request.user).select_related('course')
    
    # Get the user's recent activities
    user_activities = UserActivity.objects.filter(user=request.user).select_related('course')[:5]
    
    return render(request, 'dashboard.html', {
        'user': request.user,
        'user_courses': user_courses,
        'user_activities': user_activities
    })

def login_register(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'login.html')

def user_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, 'Successfully logged in!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid email or password.')
            return redirect('login_register')
    return redirect('login_register')

def user_register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Registration failed. Please try again.')
    return redirect('login_register')

@login_required(login_url='/accounts/login/')
def subscribe_course(request, course_id):
    course = Course.objects.get(id=course_id)
    
    # Check if user is already subscribed to this course
    if not UserCourse.objects.filter(user=request.user, course=course).exists():
        # Create a new user course subscription
        UserCourse.objects.create(
            user=request.user,
            course=course,
            progress=0
        )
        
        # Create an activity for subscribing to the course
        UserActivity.objects.create(
            user=request.user,
            course=course,
            activity_type='subscribe',
            description=f'Subscribed to {course.title}'
        )
        
        messages.success(request, f'You have successfully subscribed to {course.title}!')
    else:
        messages.info(request, f'You are already subscribed to {course.title}.')
    
    return redirect('courses')

@login_required(login_url='/accounts/login/')
def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    # Get the user's course subscription
    user_course = None
    try:
        user_course = UserCourse.objects.get(user=request.user, course=course)
    except UserCourse.DoesNotExist:
        # If user hasn't subscribed but somehow got here, redirect to courses
        return redirect('courses')
    
    # Count enrolled students
    enrolled_students = UserCourse.objects.filter(course=course).count()
    
    return render(request, 'course_detail.html', {
        'course': course,
        'user_course': user_course,
        'enrolled_students': enrolled_students
    }) 