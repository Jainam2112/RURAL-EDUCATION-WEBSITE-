from django.urls import path
from django.contrib.auth.views import LogoutView
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('services/', views.services, name='services'),
    path('courses/', views.courses, name='courses'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('login/', views.login_register, name='login_register'),
    path('login/submit/', views.user_login, name='login'),
    path('register/submit/', views.user_register, name='register'),
    path('logout/', LogoutView.as_view(next_page='/'), name='logout'),
    path('subscribe/<int:course_id>/', views.subscribe_course, name='subscribe_course'),
    path('course/<int:course_id>/', views.course_detail, name='course_detail'),
] 